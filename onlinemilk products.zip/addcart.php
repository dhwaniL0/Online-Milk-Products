<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="addcart.css">
</head>

<body>
    <h1 align="center">MY CART</h1>
    <table align='center' border='1'>
        <tr>
            <th>Serial No.</th>
            <th>Item Image</th>
            <th>Item Name</th>
            <th>Item Price</th>
            <th>Quantity</th>
            <th>Total</th>
            <th></th>
            <?php
            $total = 0; // Initialize total variable
            if (isset($_SESSION['cart'])) {
                $sr = 0; // Initialize serial number variable
                foreach ($_SESSION['cart'] as $key => $value) {
                    $sr++; // Increment serial number for each item
                    $total += $value['Price'] * $value['Quantity']; // Accumulate total price
                    echo "
                <tr>
                    <td>$sr</td>
                    <td><img src='{$value['Image']}' height='90' width='120'></td>
                    <td>{$value['Item_Name']}</td>
                    <td>{$value['Price']}<input type='hidden' class='iprice' value='{$value['Price']}'></td>
                    <td><input class='iquantity' type='number' value='{$value['Quantity']}' min='1' max='10'></td>
                    <td class='itotal'>0</td>
                    <td>
                        <form action='managecart.php' method='POST'>
                            <button type='submit' name='remove_item'>REMOVE</button>
                            <input type='hidden' name='Item_Name' value='{$value['Item_Name']}'>
                        </form>
                    </td>
                </tr>
            ";
                }
            }
            ?>
        <tr>
            <td colspan='5'>Grand Total</td>
            <td id='gtotal'><?php echo $total; ?></td>
        </tr>
    </table>
    <script>
        var gt = <?php echo $total; ?>;
        var iprice = document.getElementsByClassName('iprice');
        var iquantity = document.getElementsByClassName('iquantity');
        var itotal = document.getElementsByClassName('itotal');
        var gtotal = document.getElementById('gtotal');

        function subTotal() {
            gt = 0;
            for (var i = 0; i < iprice.length; i++) {
                itotal[i].innerText = (iprice[i].value) * (iquantity[i].value);
                gt += (iprice[i].value) * (iquantity[i].value);
            }
            gtotal.innerText = gt;
        }

        // Call subTotal() function whenever quantity changes
        for (var i = 0; i < iquantity.length; i++) {
            iquantity[i].addEventListener('change', subTotal);
        }

        // Call subTotal() function initially
        subTotal();
    </script>
</body>

</html>