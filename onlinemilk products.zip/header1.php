<html>
    <head>
        <title>Document</title>
        <a rel="stylesheet" href=""></a>
    </head>
    <body>
        <h1>MY CART</h1>
        <table border="1">
            <tr>
                <th>Serial no.</th>
                <th>Item Name</th>
                <th>Item Price</th>
                <th>Quantity</th>
                <th></th>
            </tr>
            <tr>
                <td></td>
            </tr>
        </table>
    </body>
</html>