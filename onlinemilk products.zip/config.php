<?php

$conn = mysqli_connect('localhost','root','','registration') or die('connection failed');

?>